const mongoose = require('mongoose');

mongoose.Promise = global.Promise;
mongoose.connect('mongodb+srv://PostAppAdminUser:bORcG58Qu3whZl2V@cluster0-xgobp.mongodb.net/TodoApp')
    .then(() => {
        console.log('Successfully connected to mongo db');
    }).catch(err => console.log(err));

module.exports = {
    mongoose
};