const express = require('express');
const bodyParser = require('body-parser');
const {ObjectID} = require('mongodb');
const serverless = require('serverless-http');
const cors = require('cors');

const {mongoose} = require('./db/mongoose.js');
const {TodoTask} = require('./models/TodoTask.js');
const {TodoAppUser} = require('./models/TodoAppUser.js');

const app = express();

app.use(cors());

// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());


app.post('/todos', (req, res) => {
    
    var todoTask = new TodoTask({
        todoTask: req.body.todoTask
    });
    
    todoTask.save().then((doc) => {
        res.status(200).send(doc);
    }).catch((error) => {
        res.status(400).send(error);
    });
});

app.get('/todos', (req, res) => {
    
    //Use TodoTask find method
    TodoTask.find().then((todos) => {
        res.status(200).send({todos});
    }).catch((e) => {
        res.status(400).send(e);
    });

});

app.get('/todos/:id', (req, res) => {

    var id = req.params.id;
    // Check whether Id is in valid format
    if(!ObjectID.isValid(id)){
        return res.status(404).send();
    }

    TodoTask.findById(id).then((todo) => {
        // check todo object exists
        if(!todo){
            res.status(404).send();
        }

        res.status(200).send({todo});
    }).catch((e) => {
        res.status(400).send();
    })
});

module.exports.handler = serverless(app);