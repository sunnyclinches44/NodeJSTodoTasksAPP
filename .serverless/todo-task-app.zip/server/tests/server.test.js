const request = require('supertest');
const expect = require('expect');
const {ObjectID} = require('mongodb');

const {app} = require('./../server');
var {TodoTask} = require('./../models/TodoTask');


var todos = [{
    _id: new ObjectID(),
    todoTask: 'Todo task 1 added from test suite'
}, {
    _id: new ObjectID(),
    todoTask: 'Todo task 2 added from test suite'
}];

//Hook before each test case execution
beforeEach((done) => {
    TodoTask.deleteMany().then((res) => {
        return TodoTask.insertMany(todos);
    })
    .then(() => done());
});

// describe('Test cases for post method of Todo App', () => {
    
//     // Successful scenario to create a todo task
//     it('Should create a todo task', (done) => {
//         var todoTask = 'Todo task added from the supertest';

//         request(app)
//         .post('/todos')
//         .send({todoTask})
//         .expect(200)
//         .expect((res) => {
//             expect(res.body.todoTask).toBe(todoTask);
//         })
//         .end((err, res) => {
//             if (err) {
//                 console.log(`Error as part of test case: ${JSON.stringify(err, undefined, 2)}`);
//                 return done(err);
//             }
            
//             TodoTask.find({todoTask}).then((todos) => {
//                 expect(todos.length).toBe(1);
//                 expect(todos[0].todoTask).toBe(todoTask);
//                 done(); 
//             }).catch((e) => done(e));
//         });
//     });

//     // Failure test case not to create a todo task
//     it('Should not create a todo task', (done) => {
//         var todoTask = '';

//         request(app)
//         .post('/todos')
//         .send({todoTask})
//         .expect(400)
//         .end((err, res) => {
//             if(err){
//                 console.log(`Error as part of the test case: ${JSON.stringify(err, undefined, 2)}`);
//                 return done(err);
//             }

//             TodoTask.find().then((todos) => {
//                 expect(todos.length).toBe(2);
//                 done();
//               }).catch((e) => done(e));
//         });
//     });

// });


// GET /todos test cases

// describe('GET /todos test cases', () => {

//     it('Should return all todo tasks', (done) => {

//         request(app)
//             .get('/todos')
//             .expect(200)
//             .expect((res) => {
//                 expect(res.body.todos.length).toBe(2);
//             })
//             .end(done());
//     });
// });

//GET /todos/:id test cases

describe('GET /todos/:id test cases', () => {

    // Should get a valid todo task
    // it('Should get a valid todo task', (done) => {

    //     request(app)
    //         .get(`/todos/${todos[0]._id.toHexString()}`)
    //         .expect(200)
    //         .expect((res) => {
    //             expect(res.body.todo.todoTask).toBe(todos[0].todoTask);
    //         })
    //         .end(done());
    // });

    // Should not return a valid todo task
    it('Should not return a valid todo task', (done) => {

        request(app)
            .get(`/todos/1234532`)
            .expect(404)
            .end(done);
    });

    // HexID is not present scenario
    it('HexID is not present scenario',(done) => {

        var hexID = new ObjectID().toHexString();
        request(app)
            .get(`/todos/${hexID}`)
            .expect(404)
            .end(done);
    });
});