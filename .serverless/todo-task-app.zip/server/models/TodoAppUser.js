const mongoose = require('mongoose');

var TodoAppUser = mongoose.model('TodoAppUser', {
    firstName: {
        type: String,
        required: true,
        minlength: 1,
        trim:true
    },
    lastName: {
        type: String,
        required: true,
        minlength: true,
        trim: true
    },
    email:{
        type: String,
        minlength: 1,
        required: true,
        trim: true
    }
});

module.exports = {
    TodoAppUser
};